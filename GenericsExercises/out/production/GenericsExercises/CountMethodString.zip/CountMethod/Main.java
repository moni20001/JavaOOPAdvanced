package CountMethod;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = Integer.parseInt(scan.nextLine());
       ArrayList<String> arrayList = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String el = scan.nextLine();
            arrayList.add(el);
        }
        String toCheck = scan.nextLine();
        System.out.println(Count.getCount(arrayList,toCheck));
    }
}
