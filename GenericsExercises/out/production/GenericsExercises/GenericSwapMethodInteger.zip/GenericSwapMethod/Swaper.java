package GenericSwapMethod;

import java.util.ArrayList;

public class Swaper <T>{
    private ArrayList<T> arrayList;

    public Swaper() {
        this.arrayList = new ArrayList<>();
    }


}
