package CarShop;

public interface Sellable extends Car{
    double getPrice();

}
