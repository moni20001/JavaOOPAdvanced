package SayHello;

public interface Person {
    String getName();
    String sayHello();
}
