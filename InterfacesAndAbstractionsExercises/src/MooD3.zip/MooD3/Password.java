package MooD3;

public interface Password {
    String calculatePassword();
}
