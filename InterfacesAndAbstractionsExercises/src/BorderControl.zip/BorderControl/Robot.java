package BorderControl;

public class Robot implements Soldier {
    private String model;
    private String id;

    public Robot(String model, String id) {
        this.model = model;
        this.id = id;
    }

    @Override
    public String catchFake(String n) {
        if(this.id.endsWith(n))
            return this.id;
        else
            return "";
    }
}
