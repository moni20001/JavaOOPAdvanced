package BorderControl;

public interface Soldier {
    String catchFake(String n);
}
