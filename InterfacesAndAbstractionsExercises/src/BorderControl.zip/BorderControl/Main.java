package BorderControl;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<Soldier> citizens = new LinkedList<>();
        String line = scan.nextLine();
        while (!line.equals("End")){
            String[] tokens = line.split("\\s+");
            if(tokens.length == 2){
                Soldier robot = new Robot(tokens[0],tokens[1]);
                citizens.add(robot);
            }
            if(tokens.length == 3 ){
                Soldier citizen = new Citizen(tokens[0],Integer.parseInt(tokens[1]),tokens[2]);
                citizens.add(citizen);
            }
            line = scan.nextLine();
        }
        String fakeDigits = scan.nextLine();
        for (Soldier s: citizens) {
            if(!s.catchFake(fakeDigits).equals("")){
                System.out.println(s.catchFake(fakeDigits));
            }
        }
    }
}
