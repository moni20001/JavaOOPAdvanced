package Telephony;

public interface Browse {

    void browseSite(String url);
}
