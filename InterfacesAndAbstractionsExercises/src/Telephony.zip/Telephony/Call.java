package Telephony;

public interface Call {
    void callPhone(String number);
}
