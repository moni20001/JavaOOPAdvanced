package BorderControl;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<Soldier> citizens = new LinkedList<>();
        String line = scan.nextLine();
        while (!line.equals("End")){
            String[] tokens = line.split("\\s+");
            switch (tokens[0]){
                case "Citizen":
                    Soldier citizen = new Citizen(tokens[1],Integer.parseInt(tokens[2]),tokens[3],tokens[4]);
                    citizens.add(citizen);
                    break;
                case "Pet":
                    Soldier pet = new Pet(tokens[1],tokens[2]);
                    citizens.add(pet);
                    break;
                case "Robot":
                    Soldier robot = new Robot(tokens[1],tokens[2]);
                    citizens.add(robot);
                    break;
            }



            line = scan.nextLine();
        }
        String year = scan.nextLine();
        for (Soldier s: citizens) {
            if(!s.endDate(year).equals("")){
                System.out.println(s.endDate(year));
            }
        }
    }
}
