package BorderControl;

public interface Soldier {
    String catchFake(String n);
    String endDate(String year);
    String pattern = "[0-9]{2}\\/[0-9]{2}\\/[0-9]{4}";
}
