package BorderControl;

public interface Buyer {
    void buyFood();
    int returnFood();
}
